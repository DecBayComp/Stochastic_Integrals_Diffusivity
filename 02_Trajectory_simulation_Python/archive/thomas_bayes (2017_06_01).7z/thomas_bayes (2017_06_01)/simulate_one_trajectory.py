


## Dependencies
import csv
import numpy as np
import os    # for file operations
import random
import sys    # for command-line arguments
import time    # to measure elapsed time


## Constants
execfile("./constants.py")


## External functions
execfile("./D_func.py")
execfile("./f_func.py")


## Choose the regime of D and f
# D_case_number = 1 # Parabolic diffusivity
# f_case_number = 1 # f0 = 0
if len(sys.argv) < 3:
    raise ValueError('Not enough input arguments. Two arguments expected (D, f)')
D_case_number = int(sys.argv[1])
f_case_number = int(sys.argv[2])
print('Calculating D_case = %i, f_case = %i with N = %i steps' % (D_case_number, f_case_number, N))



## Boundary conditions
if str_mode == "periodic":
	bl_periodic = True
else:
    bl_periodic = False
    

## Initialize
start_time = time.time()
np.random.seed()
t_step_internal = t_step / internal_steps_number
N_internal = N * internal_steps_number
x_lambda = np.zeros([lambda_count, N+1], dtype = float)
dx_lambda = np.zeros([lambda_count, N], dtype = float)
t_mesh = np.arange(N + 1) * t_step


## Perform a test save to ensure the process won't be killed
print("Performing a test save to ensure enough memory is available...\n")
l_ind = 1
filename = "D_%i_f_%i_lambda_%.2f_trajectory.csv" % (D_case_number, f_case_number, lambda_array[l_ind])
output_full_path = output_trajectories_folder + filename
output_data = np.stack([x_lambda[l_ind, 0:-1], dx_lambda[l_ind, :]])
output_data = np.transpose(output_data)
# Open the output file for writing
with open(output_full_path, 'wb') as file_pointer:
    csv_writer = csv.writer(file_pointer, delimiter = CSV_DELIMITER)
    csv_writer.writerows(output_data.tolist())
print('Test file save succeeded. Proceeding to calculations\n')
# Remove the temporary file
os.remove(output_full_path)


# Choosing the first point manually
x_0 = selected_x_over_L * L
x_lambda[:, 0] = x_0


## Using Verlet method for iterations
for i in range(N):
    q = np.random.normal(0.0, 1.0, internal_steps_number)    # Using the same random white noise for all constructs
    for l_ind in range(lambda_count):
        Lambda = lambda_array[l_ind]
        x_i = x_lambda[l_ind, i]
        for m in range(internal_steps_number):
            # Calculate f and D at x_i
            [f_i, _] = f_func(f_case_number, x_i, L)
            [D_i, b_prime_b_i] = D_func(D_case_number, x_i, L)
            # Convert lists to arrays
            f_i = np.asarray(f_i)
            D_i = np.asarray(D_i)
            b_prime_b_i = np.asarray(b_prime_b_i)
            a_lambda_i = f_i * D_i / kBT
            b_i = np.sqrt(2.0 * D_i)
            # print(b_prime_b_i)

            
            # Creating the noise increment W_n
            dW = np.sqrt(t_step_internal) * q[m]
            
            # Calculating increments
            dx = (a_lambda_i * t_step_internal + b_i * dW + \
                0.5 * b_prime_b_i * (dW**2 + (2.0 * Lambda - 1.0) * t_step_internal))
            x_next = x_i + dx
            ## Taking into account the BCs
            if bl_periodic:
                if x_next > x_max:
                    x_next = x_next - L
                elif x_next < x_min:
                    x_next = x_next + L
            else: 
                if x_next > x_max:
                    x_next = 2.0 * x_max - x_next
                elif x_next < x_min:
        	        x_next = 2.0 * x_min - x_next
            # Save the starting point for the next internal round
            x_i = x_next   
        
        ## Saving
        x_lambda[l_ind, i+1] = x_next
        dx_lambda[l_ind, i] = x_lambda[l_ind, i+1] - x_lambda[l_ind, i]
    
    # End cycle - iterate lambdas
    
    ## Printing out the simulation progress
    if i % update_progress_every == 0:
        print("D case: %i/%i. f case: %i/%i. Simulation progress: %.3f %%. Elapsed time: %.2f s\n" % (D_case_number, max_D_case_number, f_case_number, max_f_case_number, float(i)/N*100.0, time.time() - start_time))
    # Iterating


## Extracting jump lengths and calculating mean
# % dx_lambda = x_lambda(:, 2:end) - x_lambda(:, 1:end-1);
# mean_jump_length = mean(abs(dx_lambda), 2);

# print(x_lambda)

## Save data
print("Saving trajectory only...\n")
for l_ind in range(lambda_count):
    filename = "D_%i_f_%i_lambda_%.2f_trajectory.csv" % (D_case_number, f_case_number, lambda_array[l_ind])
    output_full_path = output_trajectories_folder + filename
    output_data = np.stack([x_lambda[l_ind, 0:-1], dx_lambda[l_ind, :]])
    output_data = np.transpose(output_data)

    # Open the output file for writing
    with open(output_full_path, 'wb') as file_pointer:
        csv_writer = csv.writer(file_pointer, delimiter = CSV_DELIMITER)
        csv_writer.writerows(output_data.tolist())

print('Trajectory saved successfully! Calculations finished in %.2f s\n' % (time.time() - start_time))








