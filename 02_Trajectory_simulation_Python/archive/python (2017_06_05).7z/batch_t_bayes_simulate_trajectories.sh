#! /bin/bash


## Constants
trials=1000
sleep_time=2
logs_folder="./logs/"

echo "Submitting tasks to kernels..."

# Create the logs folder
if [ ! -d "$logs_folder" ]; then
  mkdir $logs_folder
fi

id=1
for ((trial=1;trial<=trials;trial++))
do	
	# Fixed lambda
	for lambda in 0.0 0.5 1.0
	do
		echo "Submitting task to cluster. Trial: ${trial}. Lambda: ${lambda}..."
		# module load Python/2.7.11
		srun -o "${logs_folder}log_lambda_fixed_${id}.out" -e "${logs_folder}log_lambda_fixed_${id}.err" -J "T=${trial}_${lambda}" --cpus-per-task=1 --mem=100MB --qos=fast python2.7 simulate_one_trajectory.py -D=6 -f=7 -l=$lambda --id=$id &
		id=$((id+1))
		sleep ${sleep_time}s
		echo "Task submitted"
	done

	# Random lambda
	echo "Submitting task to cluster. Trial: ${trial}. Lambda: rand..."
	# module load Python/2.7.11
	srun -o "${logs_folder}log_lambda_rand_${trial}.out" -e "${logs_folder}log_lambda_rand_${trial}.err" -J "T=${trial}_rnd" --cpus-per-task=1 --mem=100MB --qos=fast python2.7 simulate_one_trajectory.py -D=6 -f=7 --rand --id=$trial &
	sleep ${sleep_time}s
	echo "Task submitted"
done

echo "All tasks submitted successfully!"



