#! /bin/bash

numStartI=1051
numEndI=1074
numIncrementI=1

for (( i=$numStartI; $i<=$numEndI; i=$i+$numIncrementI ))
do
	scontrol hold $i
done
