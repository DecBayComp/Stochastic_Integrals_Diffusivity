﻿print("-2")
import pandas as pd
import numpy as np
import feature_transform as ftr
import random
import copy
import pickle
import argparse
import sys

# import matplotlib.pyplot as plt

print("-1")
sys.stdout.flush()
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
from sklearn.cross_validation import KFold
from sklearn.cross_validation import StratifiedKFold
print("0")
sys.stdout.flush()
from sklearn.decomposition import PCA
from sklearn.ensemble import VotingClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import GridSearchCV

from sklearn.preprocessing import StandardScaler

CNT_HEROES = 113
EPS = 1e-5

print("1")
sys.stdout.flush()

def test_model(clf, X, y):
    if not isinstance(X, np.ndarray):
        X = np.array(X)
    if not isinstance(y, np.ndarray):
        y = np.array(y)

    kf = KFold(n=X.shape[0], n_folds=5, random_state=42)
    errors = []
    params_list = []
    for train_index, test_index in kf:
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        clf.fit(X_train, y_train)
        err = log_loss(y_test, clf.predict_proba(X_test)[:, 1])
        errors.append(err)
        print(errors)
        sys.stdout.flush()
        params_list.append(clf.get_params())
    avg_err = np.average(errors)
    return avg_err, np.array(errors)

print("2")
sys.stdout.flush()
	
X_train_matrix = pickle.load(open("./data/X_train_matrix_final.pickle", "rb"))
# X_test_matrix = pickle.load(open("./data/X_test_matrix_final.pickle", "rb"))
y_train = pickle.load(open("./data/y_train_final.pickle", "rb"))

print("3")
sys.stdout.flush()

# pickle.dump(X_train_matrix_important2, open("./X_train_matrix_important2_prot2.pickle", "wb"), protocol=2)
# pickle.dump(X_test_matrix_important2, open("./X_test_matrix_important2_prot2.pickle", "wb"), protocol=2)
# pickle.dump(y_train, open("./y_train_prot2.pickle", "wb"), protocol=2)

X_train_matrix = np.asarray(X_train_matrix, dtype=float)
# X_test_matrix = np.asarray(X_test_matrix, dtype=float)
y_train_matrix = np.asarray(y_train, dtype=int)

print("Skonczylem!!!")
sys.stdout.flush()

#C=0.077426368268112694



# parser = argparse.ArgumentParser(description='Process some integers.')
# parser.add_argument("weight", type=float)
# parser.add_argument("penalty", type=str)

# args = parser.parse_args()

args = sys.argv

weight = float(args[1])
penalty = int(args[2])
if penalty not in [1, 2]:
    raise ValueError("Wrong penalty! (Proizoshla pufnia)")
penalty = "l" + str(penalty)
print(weight)
print(penalty)

sys.stdout.flush()

C_list = np.linspace(0.001, 1, num=2)

list1 = []
list2 = []

for i, C in enumerate(C_list):
    test_clf1 = LogisticRegression(penalty=penalty, C=C,
                                   n_jobs=-1)
    test_clf2 = RandomForestClassifier(n_estimators=100, criterion="entropy",
                                       n_jobs=-1)
    clb_clf2 = CalibratedClassifierCV(test_clf2, method="isotonic", cv=5)


    test_clf = VotingClassifier([("LR", test_clf1), ("RF", clb_clf2)],
                                voting="soft",
                                weights=[weight, 1 - weight])

    avg_error, errors = test_model(test_clf, (X_train_matrix), (y_train))
    list1.append(avg_error)
    list2.append(errors)
    print(avg_error, errors)
    sys.stdout.flush()

pickle.dump(list1, file=open("./result/list1_" + penalty + "_" + str(weight) + ".pickle", "wb"), protocol=2)
pickle.dump(list2, file=open("./result/list2_" + penalty + "_" + str(weight) + ".pickle", "wb"), protocol=2)

print("Weight %f, penalty %s finished!" % (weight, penalty))
sys.stdout.flush()
print("Files " + "./result/list1_" + penalty + "_" + str(weight) + ".pickle, " +
      "./result/list2_" + penalty + "_" + str(weight) + ".pickle " + "dumped.")
sys.stdout.flush()
