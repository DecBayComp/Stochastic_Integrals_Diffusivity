#!/bin/sh

#SBATCH --qos=normal
### ~SBATCH --mem=1000
### ~SBATCH --mem-per-cpu=3000
#SBATCH --mail-user=alexander.serov@pasteur.fr
#SBATCH --cpus-per-task=24
### ~SBATCH --ntasks-per-node=1


# echo "Launching the code with parameters: C = ${1}"
# srun -o dota_$str_parameter[$j]_$i.out -e dota_$str_parameter[$j]_$i.err python2.7 dota_basic_solution_final.py  $i $str_parameter[$j]
srun python2.7 dota_basic_solution_final.py  $1
echo "Launched (batch)"


