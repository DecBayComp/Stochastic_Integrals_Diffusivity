﻿import pandas as pd
import numpy as np
import feature_transform as ftr
import random
import copy
import pickle
import argparse
import sys
import time

# import matplotlib.pyplot as plt


from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
from sklearn.cross_validation import KFold
from sklearn.cross_validation import StratifiedKFold
from sklearn.decomposition import PCA
from sklearn.ensemble import VotingClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.svm import LinearSVC

from sklearn.preprocessing import StandardScaler


def test_model(clf, X, y):
    if not isinstance(X, np.ndarray):
        X = np.array(X)
    if not isinstance(y, np.ndarray):
        y = np.array(y)

    kf = KFold(n=X.shape[0], n_folds=5, random_state=42)
    errors = []
    params_list = []
    for train_index, test_index in kf:
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        clf.fit(X_train, y_train)
        err = log_loss(y_test, clf.predict_proba(X_test)[:, 1])
        errors.append(err)
        params_list.append(clf.get_params())
    avg_err = np.average(errors)
    return avg_err, np.array(errors)


start = time.time()


X_train_matrix = pickle.load(open("./data/X_train_matrix_final.pickle", "rb"))
X_train_matrix_important = pickle.load(open("./data/X_train_matrix_final_important.pickle", "rb"))
# X_test_matrix_important = pickle.load(open("./data/X_test_matrix_final_important.pickle", "rb"))
y_train = pickle.load(open("./data/y_train_final.pickle", "rb"))


# pickle.dump(X_train_matrix_important2, open("./X_train_matrix_important2_prot2.pickle", "wb"), protocol=2)
# pickle.dump(X_test_matrix_important2, open("./X_test_matrix_important2_prot2.pickle", "wb"), protocol=2)
# pickle.dump(y_train, open("./y_train_prot2.pickle", "wb"), protocol=2)

print("Skonczylem!!!")

X_train_matrix = np.asarray(X_train_matrix, dtype=float)
X_train_matrix_important = np.asarray(X_train_matrix_important, dtype=float)
y_train_matrix = np.asarray(y_train, dtype=int)

# print(X_train_matrix.shape, X_train_matrix_important.shape, y_train_matrix.shape)


#C=0.077426368268112694



args = sys.argv

C_LR = float(args[1])
print(C_LR)
C = float(args[2])
print(C)
sys.stdout.flush()


# C_LR = 0.084
penalty = "l1"


test_clf1 = LogisticRegression(penalty=penalty, C=C_LR,
                               n_jobs=-1)
test_clf2 = RandomForestClassifier(n_estimators=100, criterion="entropy",
                                   n_jobs=-1)
clb_clf2 = CalibratedClassifierCV(test_clf2, method="isotonic", cv=5)
test_clf3 = LinearSVC(penalty="l1", dual=False, C=C)
clb_clf3 = CalibratedClassifierCV(test_clf3, method="isotonic", cv=5)

kf = KFold(n=X_train_matrix.shape[0], n_folds=5, random_state=42)
errors = []

for train_index, test_index in kf:
    X_train, X_test = X_train_matrix[train_index], X_train_matrix[test_index]
    X_train_imp, X_test_imp = X_train_matrix_important[train_index], X_train_matrix_important[test_index]
    y_train, y_test = y_train_matrix[train_index], y_train_matrix[test_index]

    test_clf1.fit(X_train_imp, y_train)
    clb_clf2.fit(X_train, y_train)
    clb_clf3.fit(X_train_imp, y_train)

    predict_lr = test_clf1.predict_proba(X_test_imp)[:, 1]
    predict_rf = clb_clf2.predict_proba(X_test)[:, 1]
    predict_svm = clb_clf3.predict_proba(X_test_imp)[:, 1]

    cur_errors = []
    num_weights = 0
    for weight_lr in list(np.linspace(0.8, 0.99, num=20)):
        num_weights = 400
        for weight_rf in list(np.linspace(0, 1 - weight_lr, num=20)):
            predict = predict_lr * weight_lr + predict_rf * weight_rf + predict_svm * (1 - weight_lr - weight_rf)
            cur_errors.append(log_loss(y_test, predict))
    errors.append(cur_errors)

    print("Penalty: %s, C_LR: %f, C_SVM: %f\n" % (penalty, C_LR, C))
    print("Errors_cur_fold: ", cur_errors)
    print("\n")
    sys.stdout.flush()

    cur_time = time.time() - start
    print("Cur time, ", cur_time)
    print("\n")
    sys.stdout.flush()


avg_err = np.zeros(num_weights)
for i in range(5):
    for j in range(num_weights):
        avg_err[j] += errors[i][j]

avg_err /= 5.0

print("Penalty: %s, C_LR: %f, C_SVM: %f\n" % (penalty, C_LR, C))
print("Errors_avg: ", avg_err)
print("\n")
sys.stdout.flush()

cur_time = time.time() - start
print("Cur time, ", cur_time)
print("\n")
sys.stdout.flush()


pickle.dump(avg_err, file=open("./result/avg_err_LR_" + str(C_LR) + "_SVM_" + str(C) + ".pickle", "wb"), protocol=2)
pickle.dump(errors, file=open("./result/errors_LR_" + str(C_LR) + "_SVM_" + str(C) + ".pickle", "wb"), protocol=2)

print("C %f, penalty %s finished!\n" % (C, penalty))
print("Files " + "./result/avg_err_LR_" + str(C_LR) + "_SVM_" + str(C) + ".pickle, " +
      "./result/errors_LR_" + str(C_LR) + "_SVM_" + str(C) + ".pickle " + "dumped.\n")
sys.stdout.flush()
