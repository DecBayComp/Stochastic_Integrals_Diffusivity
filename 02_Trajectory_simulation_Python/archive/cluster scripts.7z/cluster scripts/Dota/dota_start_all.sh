#! /bin/sh

### ~SBATCH --ntasks-per-node=24
#SBATCH --qos=normal
#SBATCH --cpus-per-task=1
### ~SBATCH --mem=1000
### ~SBATCH --mem-per-cpu=200
#SBATCH --mail-user=alexander.serov@pasteur.fr
### ~SBATCH -n1
### ~SBATCH -N1

### rm *.out *.err

echo "Starting global..."

# Variables arrays
#numStartI=10
#numEndI=10000
#numIncrementI=900

#numStartJ=10
#numEndJ=10000
#numIncrementJ=900

# Test
numStartI=10010
numEndI=10020
numIncrementI=10

numStartJ=10010
numEndJ=10010
numIncrementJ=10


for (( i=$numStartI; $i<=$numEndI; i=$i+$numIncrementI ))
do
	for (( j=$numStartJ; $j<=$numEndJ; j=$j+$numIncrementJ ))
	do
		float_i=$(bc <<< "scale=5;$i/10000.0")
		float_j=$(bc <<< "scale=5;$j/10000.0")
		echo "Launching the code with parameters: C_LR = "$float_i", C_SVM = "$float_j
		
		

		# sbatch -o dota_$strParameter[$j]_$float_i.out -e dota_$strParameter[$j]_$float_i.err python2.7 dota_basic_solution_2016_11_14.py  $float_i $strParameter[$j]
		srun -o dota_${float_i}_${float_j}.out -e dota_${float_i}_${float_j}.err -J dt_${i}_${j} python2.7 dota_basic_solution_final.py $float_i $float_j
		echo "Launched (global)"
	done
done
