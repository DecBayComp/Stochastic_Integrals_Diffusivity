import pandas as pd
import numpy as np


def del_categorial(X):
    categorial = ["lobby_type", "r1_hero", "r2_hero", "r3_hero", "r4_hero",
                  "r5_hero", "d1_hero", "d2_hero", "d3_hero", "d4_hero",
                  "d5_hero"]
    X_new = X.drop(categorial, axis=1)

    return X_new


def nan_to_median(X, feats_with_nans=None):
    X_new = X.copy()

    if not feats_with_nans:
        X_matrix = X.as_matrix()

        nans = np.nonzero(np.isnan(X_matrix))
        feats_with_nans = list(np.unique(nans[1]))

    for feat in feats_with_nans:
        temp = X_new.iloc[:, feat]
        temp.loc[np.isnan(temp)] =\
            np.median(temp.loc[np.logical_not(np.isnan(temp))])

    return X_new

def sack_of_heroes(X, heroes_names):
    # N -- number of different heroes in subset
    X_pick = np.zeros((X.shape[0], heroes_names.shape[0]))

    for i, match_id in enumerate(X.index):
        for p in range(5):
            X_pick[i, X.ix[match_id, 'r%d_hero' % (p + 1)] - 1] = 1
            X_pick[i, X.ix[match_id, 'd%d_hero' % (p + 1)] - 1] = -1

    X_pick_df = pd.DataFrame(X_pick, index=X.index, columns=heroes_names)
    print(X_pick_df.shape)

    X_new = X.copy()
    X_new = pd.concat([X_new, X_pick_df], axis=1)

    return X_new