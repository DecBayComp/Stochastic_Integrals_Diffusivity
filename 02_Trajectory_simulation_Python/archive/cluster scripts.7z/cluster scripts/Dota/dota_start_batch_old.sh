#!/bin/sh

### #SBATCH -o "dota_"$1"_"$2".out" -e "dota_"$1"_"$2".err"
### #SBATCH -J "dota_"$1"_"$2


# echo "Launching the code with parameters: ${1}, ${2}"
# srun -o dota_$str_parameter[$j]_$i.out -e dota_$str_parameter[$j]_$i.err python2.7 dota_basic_solution_2016_11_14.py  $i $str_parameter[$j]
srun python2.7 dota_basic_solution_2016_11_14.py  $1 $2
echo "Launched (batch)"


