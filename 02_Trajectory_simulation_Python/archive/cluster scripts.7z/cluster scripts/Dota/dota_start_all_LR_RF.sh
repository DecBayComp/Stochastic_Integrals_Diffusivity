#! /bin/bash

# rm *.out *.err

echo "Starting global..."

# Variables arrays
numStart=10
numEnd=3000
numIncrement=83


for (( i=$numStart; $i<=$numEnd; i=$i+$numIncrement ))
do
	float_i=$(bc <<< "scale=5;$i/10000.0")
	echo "Launching the code with parameters: C = "$float_i
	

	# sbatch -o dota_$strParameter[$j]_$float_i.out -e dota_$strParameter[$j]_$float_i.err python2.7 dota_basic_solution_2016_11_14.py  $float_i $strParameter[$j]
	sbatch -o dota_${float_i}.out -e dota_${float_i}.err -J dt_${i} dota_start_batch.sh $float_i
	echo "Launched (global)"
done

