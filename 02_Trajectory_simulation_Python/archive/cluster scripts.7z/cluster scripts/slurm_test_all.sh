#! /bin/bash

# rm *.out *.err

echo "Starting global..."

# Variables arrays
numStart=80
numEnd=95
numIncrement=1
# num_tries = 5

# strParameter=("l1" "l2")
# $strParameter[1]="l2"

for j in 1 2

do
	for (( i=$numStart; $i<=$numEnd; i=$i+$numIncrement ))
	do
		float_i=$(bc <<< "scale=2;$i/100.0")
		echo "Launching the code with parameters:"$j", "$float_i
		
	
		# sbatch -o dota_$strParameter[$j]_$float_i.out -e dota_$strParameter[$j]_$float_i.err python2.7 dota_basic_solution_2016_11_14.py  $float_i $strParameter[$j]
		sbatch -o dota_${j}_${float_i}.out -e dota_${j}_${float_i}.err -J dt_${j}_${i} --cpus-per-task=1 slurm_test_batch.sh $float_i $j
		echo "Launched (global)"
	done
done

