import time


time.sleep(600)
